#include <stdio.h>
int main(int argc, char const *argv[]){
	for (int i = 122; i >96 ; i--)
	{
		printf("%c\n",i );
	}
}
