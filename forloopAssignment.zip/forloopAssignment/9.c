#include<stdio.h>

int main(){

    for (int i = 30; i > 14; i-=2)
     {
     	printf("%d\n",i );
     }
}
