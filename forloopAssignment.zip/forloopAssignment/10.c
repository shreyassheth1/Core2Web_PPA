#include <stdio.h>
int main() {
	for (int i = 1; i < 26; ++i)
	{
		if(65%i==0){
			printf("%d\n",i);
		}
	}

return 0;
}
