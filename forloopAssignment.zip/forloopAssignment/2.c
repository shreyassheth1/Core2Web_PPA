#include <stdio.h>
void main() {
     for (int i = 21; i < 40; i+=2)
     {
     	printf("%d\n",i );
     }
  }
  //case is not a predefined constant value hence it will be an error