#include <stdio.h>
int main(){

    for (int i = 1; i < 129; ++i)
	{
		printf("%c =%d\n",i,i );
		
	}
        return 0;
}
