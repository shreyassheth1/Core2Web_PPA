#include<stdio.h>

int main(){

    for (int i = 50; i < 71; i+=2)
     {
     	printf("%d\n",i );
     }
}
