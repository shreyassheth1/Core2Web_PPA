#include <stdio.h>
int main() {
	for (int i = 1; i < 26; ++i)
	{
		if(50%i==0){
			printf("%d %d\n",i,50/i );
		}
	}

return 0;
}
